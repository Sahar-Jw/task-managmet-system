// frontend/src/app/dashboard/page.tsx

'use client';

import { uiText } from '@/lib/ui-text';
import InlineLoader from '@/components/InlineLoader';
import Avatar from '@/components/Avatar';

import {
  useEffect,
  useMemo,
  useState,
} from 'react';

import Link from 'next/link';

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import {
  useLocale,
} from 'next-intl';

import ProtectedRoute from '@/components/ProtectedRoute';
import StatusBadge from '@/components/StatusBadge';

import {
  useAuth,
} from '@/lib/auth-context';

import {
  useListLabels,
} from '@/lib/list-labels-context';

import {
  ApiError,
} from '@/lib/api';

import {
  ProjectsApi,
  ReportsApi,
  SettingsApi,
  TasksApi,
} from '@/lib/endpoints';

import type {
  Project,
  Setting,
  Task,
} from '@/lib/types';


/*
 * ============================================================
 * TYPES
 * ============================================================
 */

interface OverviewRow {
  totalTasks: string;
  completedTasks: string;
  overdueTasks: string;
}


interface BranchRow
  extends OverviewRow {
  branchId: string;
  branchNameEn?: string;
  branchNameAr?: string;
}


interface DepartmentRow
  extends OverviewRow {
  departmentId: string;
  departmentNameEn?: string;
  departmentNameAr?: string;
}


function formatProjectDate(
  value:
    string | undefined,

  locale:
    string,
) {
  if (!value) {
    return '—';
  }


  return new Date(
    `${value}T00:00:00`,
  ).toLocaleDateString(
    locale,
  );
}


function dashboardProjectIsOverdue(
  project:
    Project,
) {
  if (
    !project.endDate ||
    project.status ===
      'Completed' ||
    project.status ===
      'Archived'
  ) {
    return false;
  }


  const today =
    new Date()
      .toISOString()
      .slice(
        0,
        10,
      );


  return (
    project.endDate <
    today
  );
}


/*
 * ============================================================
 * SMALL UI COMPONENTS
 * ============================================================
 */

function SectionHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h2 className="text-base font-semibold text-slate-900">
          {title}
        </h2>

        {description && (
          <p className="mt-1 text-sm leading-6 text-slate-500">
            {description}
          </p>
        )}
      </div>

      {action}
    </div>
  );
}


function MetricCard({
  title,
  value,
  description,
  icon,
  href,
  tone = 'brand',
}: {
  title: string;
  value: string | number;
  description: string;
  icon: React.ReactNode;
  href?: string;

  tone?:
    | 'brand'
    | 'green'
    | 'amber'
    | 'red';
}) {
  const styles = {
    brand: {
      icon:
        'bg-brand-50 text-brand-700 ring-brand-100',

      bar:
        'bg-brand-500',
    },

    green: {
      icon:
        'bg-green-50 text-green-700 ring-green-100',

      bar:
        'bg-green-500',
    },

    amber: {
      icon:
        'bg-amber-50 text-amber-700 ring-amber-100',

      bar:
        'bg-amber-500',
    },

    red: {
      icon:
        'bg-red-50 text-red-700 ring-red-100',

      bar:
        'bg-red-500',
    },
  }[tone];


  const content = (
    <div
      className={`group relative h-full overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 transition ${
        href
          ? 'hover:-translate-y-0.5 hover:border-brand-200 hover:shadow-lg'
          : ''
      }`}
    >
      <div
        className={`absolute inset-x-0 top-0 h-[3px] ${styles.bar}`}
      />

      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-slate-500">
            {title}
          </p>

          <p className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-slate-950">
            {value}
          </p>

          <p className="mt-1.5 text-xs leading-5 text-slate-400">
            {description}
          </p>
        </div>


        <div
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ring-1 ${styles.icon}`}
        >
          {icon}
        </div>
      </div>
    </div>
  );


  if (
    href
  ) {
    return (
      <Link
        href={href}
        className="block"
      >
        {content}
      </Link>
    );
  }


  return content;
}


function EmptyState({
  title,
  description,
  icon,
}: {
  title: string;
  description: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex min-h-[200px] flex-col items-center justify-center px-6 py-10 text-center">
      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-slate-400">
        {icon ?? (
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            className="h-5 w-5"
          >
            <path
              d="M6 7h12M6 12h12M6 17h8"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </svg>
        )}
      </div>

      <div className="mt-3 text-sm font-medium text-slate-700">
        {title}
      </div>

      <p className="mt-1 max-w-xs text-xs leading-5 text-slate-400">
        {description}
      </p>
    </div>
  );
}


function ChartEmptyState({
  message,
}: {
  message: string;
}) {
  return (
    <div className="flex h-[320px] items-center justify-center">
      <EmptyState
        title={message}
        description="More data will appear here as tasks are created and completed."
        icon={
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            className="h-5 w-5"
          >
            <path
              d="M5 19V9M12 19V5M19 19v-7"
              strokeWidth="1.8"
              strokeLinecap="round"
            />

            <path
              d="M3 19h18"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
          </svg>
        }
      />
    </div>
  );
}


/*
 * ============================================================
 * DASHBOARD
 * ============================================================
 */

function DashboardContent() {
  const {
    user,
  } = useAuth();

  const locale =
    useLocale();

  const isAr =
    locale === 'ar';

  const {
    getLabel,
  } = useListLabels();


  const isAdmin =
    user?.role?.name ===
    'ADMIN';


  /*
   * ==========================================================
   * DATA
   * ==========================================================
   */

  const [
    tasks,
    setTasks,
  ] = useState<Task[]>(
    [],
  );

  const [
    assignedByMeTasks,
    setAssignedByMeTasks,
  ] = useState<Task[]>(
    [],
  );

  const [
    projects,
    setProjects,
  ] = useState<Project[]>(
    [],
  );


  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    error,
    setError,
  ] = useState('');


  /*
   * SETTINGS
   */

  const [
    taskStatuses,
    setTaskStatuses,
  ] = useState<Setting[]>(
    [],
  );

  const [
    taskTypes,
    setTaskTypes,
  ] = useState<Setting[]>(
    [],
  );

  const [
    taskPriorities,
    setTaskPriorities,
  ] = useState<Setting[]>(
    [],
  );

  const [
    projectStatuses,
    setProjectStatuses,
  ] = useState<Setting[]>(
    [],
  );


  /*
   * REPORTS
   */

  const [
    monthly,
    setMonthly,
  ] = useState<
    {
      month: string;
      done: number;
      notDone: number;
    }[]
  >([]);


  const [
    branches,
    setBranches,
  ] = useState<BranchRow[]>(
    [],
  );


  const [
    departments,
    setDepartments,
  ] = useState<
    DepartmentRow[]
  >([]);


  const [
    statsLoading,
    setStatsLoading,
  ] = useState(true);


  const [
    statsError,
    setStatsError,
  ] = useState('');


  /*
   * ==========================================================
   * LOAD MAIN DATA
   * ==========================================================
   */

  useEffect(() => {
    setLoading(
      true,
    );

    setError('');


    const fetchTasks =
      isAdmin
        ? TasksApi.list({
            limit: '100',
          })
        : TasksApi.mine({
            limit: '100',
          });


    fetchTasks
      .then(
        (response) => {
          setTasks(
            response.items,
          );
        },
      )
      .catch(
        (err) => {
          setError(
            err instanceof ApiError
              ? err.message
              : uiText(isAr, 'text0278'),
          );
        },
      )
      .finally(
        () => {
          setLoading(
            false,
          );
        },
      );


    TasksApi.assignedByMe({
      limit: '5',
      sortBy: 'createdAt',
      sortDir: 'desc',
    })
      .then(
        (
          response,
        ) => {
          setAssignedByMeTasks(
            response.items,
          );
        },
      )
      .catch(
        () => {
          setAssignedByMeTasks(
            [],
          );
        },
      );


    ProjectsApi.list({
      limit: '100',
    })
      .then(
        (response) => {
          setProjects(
            response.items,
          );
        },
      )
      .catch(
        () => {},
      );


    SettingsApi.list(
      'task_status',
      true,
    )
      .then(
        setTaskStatuses,
      )
      .catch(
        () => {},
      );


    SettingsApi.list(
      'task_type',
      true,
    )
      .then(
        setTaskTypes,
      )
      .catch(
        () => {},
      );


    SettingsApi.list(
      'task_priority',
      true,
    )
      .then(
        setTaskPriorities,
      )
      .catch(
        () => {},
      );


    SettingsApi.list(
      'project_status',
      true,
    )
      .then(
        setProjectStatuses,
      )
      .catch(
        () => {},
      );
  }, [
    isAdmin,
    isAr,
  ]);


  /*
   * ==========================================================
   * LOAD ANALYTICS
   * ==========================================================
   */

  useEffect(() => {
    setStatsLoading(
      true,
    );

    setStatsError('');


    Promise.all([
      ReportsApi.monthlySummary({
        months: '12',
      }),

      ReportsApi.branchOverview(),

      ReportsApi.departmentOverview(),
    ])
      .then(
        ([
          monthlyResult,
          branchResult,
          departmentResult,
        ]) => {
          setMonthly(
            monthlyResult,
          );

          setBranches(
            branchResult as
              BranchRow[],
          );

          setDepartments(
            departmentResult as
              DepartmentRow[],
          );
        },
      )
      .catch(
        (err) => {
          setStatsError(
            err instanceof ApiError
              ? err.message
              : uiText(isAr, 'text0013'),
          );
        },
      )
      .finally(
        () => {
          setStatsLoading(
            false,
          );
        },
      );
  }, [
    isAr,
  ]);


  /*
   * ==========================================================
   * LANGUAGE
   * ==========================================================
   */

  function inCurrentLocale(
    setting: Setting,
  ) {
    return Boolean(
      isAr
        ? setting.codeAr
        : setting.codeEn,
    );
  }


  function taskTitle(
    task: Task,
  ) {
    return task.title;
  }


  function monthLabel(
    key: string,
  ) {
    const [
      year,
      month,
    ] =
      key
        .split('-')
        .map(
          Number,
        );


    return new Intl.DateTimeFormat(
      locale,
      {
        month:
          'short',

        year:
          '2-digit',
      },
    ).format(
      new Date(
        year,
        month - 1,
        1,
      ),
    );
  }


  /*
   * ==========================================================
   * STATUS / TYPE / PRIORITY COUNTS
   * ==========================================================
   */

  const counts =
    taskStatuses
      .filter(
        inCurrentLocale,
      )
      .map(
        (
          setting,
        ) => ({
          status:
            setting.key!,

          label:
            getLabel(
              'task_status',
              setting.key!,
            ),

          count:
            tasks.filter(
              (
                task,
              ) =>
                task.status ===
                setting.key,
            ).length,
        }),
      );


  const typeCounts =
    taskTypes
      .filter(
        inCurrentLocale,
      )
      .map(
        (
          setting,
        ) => ({
          taskType:
            setting.key!,

          label:
            getLabel(
              'task_type',
              setting.key!,
            ),

          count:
            tasks.filter(
              (
                task,
              ) =>
                task.taskType ===
                setting.key,
            ).length,
        }),
      );


  const priorityCounts =
    taskPriorities
      .filter(
        inCurrentLocale,
      )
      .map(
        (
          setting,
        ) => ({
          priority:
            setting.key!,

          label:
            getLabel(
              'task_priority',
              setting.key!,
            ),

          count:
            tasks.filter(
              (
                task,
              ) =>
                task.priority ===
                setting.key,
            ).length,
        }),
      );


  const projectStatusCounts =
    projectStatuses
      .filter(
        inCurrentLocale,
      )
      .map(
        (
          setting,
        ) => ({
          status:
            setting.key!,

          label:
            getLabel(
              'project_status',
              setting.key!,
            ),

          count:
            projects.filter(
              (
                project,
              ) =>
                project.status ===
                setting.key,
            ).length,
        }),
      );


  /*
   * ==========================================================
   * COMPLETION LOGIC
   * ==========================================================
   */

  const completedTaskKeys =
    useMemo(
      () => {
        const matching =
          taskStatuses
            .filter(
              (
                setting,
              ) => {
                const key =
                  setting.key
                    ?.toLowerCase() ??
                  '';


                return (
                  key.includes(
                    'complete',
                  ) ||
                  key.includes(
                    'finish',
                  ) ||
                  key ===
                    'done'
                );
              },
            )
            .map(
              (
                setting,
              ) =>
                setting.key!,
            );


        return new Set([
          ...matching,

          'Completed',
          'Finished',
          'Done',
        ]);
      },
      [
        taskStatuses,
      ],
    );


  /*
   * ==========================================================
   * KPIs
   * ==========================================================
   */

  const totalTaskCount =
    tasks.length;


  const completedTaskCount =
    tasks.filter(
      (
        task,
      ) =>
        completedTaskKeys.has(
          task.status,
        ),
    ).length;


  const overdueTasks =
    tasks.filter(
      (
        task,
      ) => {
        if (
          !task.deadlineDate
        ) {
          return false;
        }


        if (
          completedTaskKeys.has(
            task.status,
          )
        ) {
          return false;
        }


        if (
          task.status ===
          'Archived'
        ) {
          return false;
        }


        return (
          new Date(
            task.deadlineDate,
          ).getTime() <
          Date.now()
        );
      },
    );


  const overdueTaskCount =
    overdueTasks.length;


  const openTaskCount =
    tasks.filter(
      (
        task,
      ) =>
        !completedTaskKeys.has(
          task.status,
        ) &&
        task.status !==
          'Archived',
    ).length;


  const completionRate =
    totalTaskCount ===
    0
      ? 0
      : Math.round(
          (
            completedTaskCount /
            totalTaskCount
          ) *
            100,
        );


  /*
   * ==========================================================
   * TASK LISTS
   * ==========================================================
   */

  const latestTasks =
    [
      ...tasks,
    ]
      .sort(
        (
          a,
          b,
        ) =>
          new Date(
            b.createdAt,
          ).getTime() -
          new Date(
            a.createdAt,
          ).getTime(),
      )
      .slice(
        0,
        5,
      );


  const latestProjects =
    [
      ...projects,
    ]
      .sort(
        (
          a,
          b,
        ) =>
          new Date(
            b.createdAt,
          ).getTime() -
          new Date(
            a.createdAt,
          ).getTime(),
      )
      .slice(
        0,
        5,
      );


  const todayDate =
    new Date()
      .toISOString()
      .slice(
        0,
        10,
      );


  const upcoming =
    tasks
      .filter(
        (
          task,
        ) =>
          Boolean(
            task.deadlineDate,
          ) &&
          task.deadlineDate! >=
            todayDate &&
          !completedTaskKeys.has(
            task.status,
          ) &&
          task.status !==
            'Archived',
      )
      .sort(
        (
          a,
          b,
        ) =>
          a.deadlineDate!.localeCompare(
            b.deadlineDate!,
          ),
      )
      .slice(
        0,
        6,
      );


  const upcomingProjects =
    projects
      .filter(
        (
          project,
        ) =>
          Boolean(
            project.endDate,
          ) &&
          project.endDate! >=
            todayDate &&
          project.status !==
            'Completed' &&
          project.status !==
            'Archived',
      )
      .sort(
        (
          a,
          b,
        ) =>
          a.endDate!.localeCompare(
            b.endDate!,
          ),
      )
      .slice(
        0,
        5,
      );


  /*
   * Tasks that need the most immediate attention.
   */

  const attentionTasks =
    [
      ...overdueTasks,
    ]
      .sort(
        (
          a,
          b,
        ) =>
          (
            a.deadlineDate ??
            ''
          ).localeCompare(
            b.deadlineDate ??
              '',
          ),
      )
      .slice(
        0,
        4,
      );


  const attentionProjects =
    projects
      .filter(
        dashboardProjectIsOverdue,
      )
      .sort(
        (
          a,
          b,
        ) =>
          a.endDate!.localeCompare(
            b.endDate!,
          ),
      )
      .slice(
        0,
        4,
      );


  /*
   * ==========================================================
   * CHART DATA
   * ==========================================================
   */

  const monthlyChartData =
    monthly.map(
      (
        item,
      ) => ({
        month:
          monthLabel(
            item.month,
          ),

        Completed:
          item.done,

        'Not completed':
          item.notDone,
      }),
    );


  const branchChartData =
    [
      ...branches,
    ]
      .map(
        (
          branch,
        ) => ({
          name:
            (isAr
              ? branch.branchNameAr || branch.branchNameEn
              : branch.branchNameEn || branch.branchNameAr) ??
            (
              uiText(isAr, 'text0014')
            ),

          Completed:
            Number(
              branch.completedTasks,
            ),

          Overdue:
            Number(
              branch.overdueTasks,
            ),

          Total:
            Number(
              branch.totalTasks,
            ),
        }),
      )
      .sort(
        (
          a,
          b,
        ) =>
          b.Total -
          a.Total,
      );


  const departmentChartData =
    [
      ...departments,
    ]
      .map(
        (
          department,
        ) => ({
          name:
            (isAr
              ? department.departmentNameAr || department.departmentNameEn
              : department.departmentNameEn || department.departmentNameAr) ??
            (
              uiText(isAr, 'text0014')
            ),

          Completed:
            Number(
              department.completedTasks,
            ),

          Overdue:
            Number(
              department.overdueTasks,
            ),

          Total:
            Number(
              department.totalTasks,
            ),
        }),
      )
      .sort(
        (
          a,
          b,
        ) =>
          b.Total -
          a.Total,
      );


  const branchChartHeight =
    Math.max(
      280,
      branchChartData.length *
        50,
    );


  const departmentChartHeight =
    Math.max(
      280,
      departmentChartData.length *
        50,
    );


  /*
   * ==========================================================
   * LINKS
   * ==========================================================
   */

  function taskListHref(
    query = '',
  ) {
    const base =
      isAdmin
        ? '/tasks'
        : '/tasks/mine';


    return query
      ? `${base}?${query}`
      : base;
  }


  /*
   * ==========================================================
   * GREETING
   * ==========================================================
   */

  const firstName =
    user?.fullName
      ?.trim()
      .split(
        ' ',
      )[0] ??
    '';


  /*
   * ==========================================================
   * LOADING
   * ==========================================================
   */

  if (
    loading
  ) {
    return <InlineLoader className="min-h-[320px]" />;
  }


  /*
   * ==========================================================
   * RENDER
   * ==========================================================
   */

  return (
    <div
      className="mx-auto max-w-[1600px] pb-12"
      dir={
        isAr
          ? 'rtl'
          : 'ltr'
      }
    >
      {/*
       * ======================================================
       * HEADER
       * ======================================================
       */}

      <section className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white px-5 py-6 sm:px-7">
        <div className="pointer-events-none absolute -right-32 -top-32 h-72 w-72 rounded-full bg-brand-50 blur-3xl" />


        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex min-w-0 items-start gap-3">
            <Avatar
              name={user?.fullName || firstName || 'User'}
              avatarUrl={user?.avatarUrl}
              size="md"
              className="shrink-0"
            />

            <div>
            <div className="text-xs font-semibold uppercase tracking-[.14em] text-brand-600">
              {uiText(isAr, 'text0279')}
            </div>


            <h1 className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-slate-950 sm:text-3xl">
              {uiText(isAr, 'text0725', { value0: firstName })}
            </h1>


            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">
              {isAdmin
                ? uiText(isAr, 'text0280')
                : uiText(isAr, 'text0281')}
            </p>
            </div>
          </div>


          <div className="flex flex-wrap gap-2">
            <Link
              href={
                taskListHref()
              }
              className="btn-secondary"
            >
              {uiText(isAr, 'text0015')}
            </Link>


            <Link
              href="/tasks/new"
              className="btn-primary"
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                className="mr-1.5 h-4 w-4"
              >
                <path
                  d="M12 5v14M5 12h14"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>

              {uiText(isAr, 'text0016')}
            </Link>
          </div>
        </div>
      </section>


      {/*
       * ======================================================
       * LATEST TASKS ASSIGNED BY ME
       * ======================================================
       */}

      <section className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <div className="border-b border-slate-100 p-5 sm:p-6">
          <SectionHeader
            title={
              uiText(isAr, 'text1032')
            }
            description={
              uiText(isAr, 'text1033')
            }
            action={
              <Link
                href="/tasks/mine?tab=assignedByMe"
                className="text-xs font-medium text-brand-600 hover:text-brand-800"
              >
                {uiText(isAr, 'text1034')}
              </Link>
            }
          />
        </div>


        {assignedByMeTasks.length ===
        0 ? (
          <EmptyState
            title={
              uiText(isAr, 'text1035')
            }
            description={
              uiText(isAr, 'text1036')
            }
          />
        ) : (
          <div className="divide-y divide-slate-100">
            {assignedByMeTasks.map(
              (
                task,
              ) => (
                <Link
                  key={
                    task.id
                  }
                  href={`/tasks/${task.id}`}
                  className="group grid gap-3 px-5 py-4 transition hover:bg-slate-50 sm:grid-cols-[minmax(0,1fr)_150px_150px] sm:items-center sm:px-6"
                >
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium text-slate-800 group-hover:text-brand-700">
                      {taskTitle(
                        task,
                      )}
                    </div>

                    <div className="mt-1 text-xs text-slate-400">
                      {uiText(isAr, 'text0032')}{' '}

                      {new Date(
                        task.createdAt,
                      ).toLocaleDateString(
                        locale,
                      )}
                    </div>
                  </div>


                  <div className="flex sm:justify-center">
                    <StatusBadge
                      value={
                        task.priority
                      }
                      listType="task_priority"
                    />
                  </div>


                  <div className="flex sm:justify-end">
                    <StatusBadge
                      value={
                        task.status
                      }
                      listType="task_status"
                    />
                  </div>
                </Link>
              ),
            )}
          </div>
        )}
      </section>


      {/*
       * ======================================================
       * ERROR
       * ======================================================
       */}

      {error && (
        <div className="mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      )}


      {/*
       * ======================================================
       * KPI CARDS
       * ======================================================
       */}

      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          title={
            uiText(isAr, 'text0017')
          }
          value={
            totalTaskCount
          }
          description={
            isAdmin
              ? uiText(isAr, 'text0282')
              : uiText(isAr, 'text0283')
          }
          href={
            taskListHref()
          }
          tone="brand"
          icon={
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              className="h-5 w-5"
            >
              <path
                d="M8 7h11M8 12h11M8 17h7"
                strokeWidth="1.8"
                strokeLinecap="round"
              />

              <path
                d="m3 7 1 1 2-2m-3 6 1 1 2-2m-3 6 1 1 2-2"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          }
        />


        <MetricCard
          title={
            uiText(isAr, 'text0018')
          }
          value={
            completedTaskCount
          }
          description={
            uiText(isAr, 'text0726', { value0: completionRate })
          }
          tone="green"
          icon={
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              className="h-5 w-5"
            >
              <circle
                cx="12"
                cy="12"
                r="8"
                strokeWidth="1.8"
              />

              <path
                d="m8.5 12 2.2 2.2 4.8-5"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          }
        />


        <MetricCard
          title={
            uiText(isAr, 'text0019')
          }
          value={
            openTaskCount
          }
          description={
            uiText(isAr, 'text0284')
          }
          tone="amber"
          icon={
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              className="h-5 w-5"
            >
              <circle
                cx="12"
                cy="12"
                r="8"
                strokeWidth="1.8"
              />

              <path
                d="M12 8v4l2.8 1.8"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </svg>
          }
        />


        <MetricCard
          title={
            uiText(isAr, 'text0285')
          }
          value={
            overdueTaskCount
          }
          description={
            overdueTaskCount >
            0
              ? uiText(isAr, 'text0020')
              : uiText(isAr, 'text0286')
          }
          href={
            taskListHref(
              'overdueOnly=true',
            )
          }
          tone="red"
          icon={
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              className="h-5 w-5"
            >
              <path
                d="M12 9v4m0 4h.01M10.3 4.6 3.2 17a2 2 0 0 0 1.7 3h14.2a2 2 0 0 0 1.7-3L13.7 4.6a2 2 0 0 0-3.4 0Z"
                strokeWidth="1.7"
                strokeLinecap="round"
              />
            </svg>
          }
        />
      </section>


      {/*
       * ======================================================
       * STATUS OVERVIEW
       * ======================================================
       */}

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
        <SectionHeader
          title={
            uiText(isAr, 'text0287')
          }
          description={
            uiText(isAr, 'text0021')
          }
          action={
            <Link
              href={
                taskListHref()
              }
              className="text-xs font-medium text-brand-600 hover:text-brand-800"
            >
              {uiText(isAr, 'text0022')}
            </Link>
          }
        />


        {counts.length >
          0 ? (
          <div className="mt-5 grid gap-3 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
            {counts.map(
              (
                item,
              ) => (
                <Link
                  key={
                    item.status
                  }
                  href={
                    taskListHref(
                      `status=${encodeURIComponent(
                        item.status,
                      )}`,
                    )
                  }
                  className="group rounded-xl border border-slate-200 bg-slate-50/40 p-4 transition hover:border-brand-200 hover:bg-brand-50/40"
                >
                  <div className="flex items-center justify-between gap-3">
                    <StatusBadge
                      value={
                        item.status
                      }
                      listType="task_status"
                    />

                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      className="h-4 w-4 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-brand-500"
                    >
                      <path
                        d="m9 18 6-6-6-6"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>

                  <div className="mt-4 text-2xl font-semibold tracking-tight text-slate-900">
                    {
                      item.count
                    }
                  </div>

                  <div className="mt-1 text-xs text-slate-400">
                    {item.count ===
                    1
                      ? uiText(isAr, 'text0023')
                      : uiText(isAr, 'text0024')}
                  </div>
                </Link>
              ),
            )}
          </div>
        ) : (
          <EmptyState
            title={
              uiText(isAr, 'text0025')
            }
            description={
              uiText(isAr, 'text0288')
            }
          />
        )}
      </section>


      {/*
       * ======================================================
       * ATTENTION + UPCOMING
       * ======================================================
       */}

      <section className="mt-6 grid gap-6 xl:grid-cols-[1fr_1fr]">
        {/*
         * ATTENTION
         */}

        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <div className="border-b border-slate-100 p-5 sm:p-6">
            <SectionHeader
              title={
                uiText(isAr, 'text0020')
              }
              description={
                uiText(isAr, 'text0289')
              }
            />
          </div>


          {attentionTasks.length ===
            0 &&
          attentionProjects.length ===
            0 ? (
            <EmptyState
              title={
                uiText(isAr, 'text0290')
              }
              description={
                uiText(isAr, 'text0291')
              }
              icon={
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  className="h-5 w-5"
                >
                  <path
                    d="m6 12 4 4 8-9"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              }
            />
          ) : (
            <div className="divide-y divide-slate-100">
              {attentionTasks.length >
                0 && (
                <div className="bg-slate-50 px-5 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500 sm:px-6">
                  {uiText(isAr, 'text1020')}
                </div>
              )}


              {attentionTasks.map(
                (
                  task,
                ) => (
                  <Link
                    key={
                      task.id
                    }
                    href={`/tasks/${task.id}`}
                    className="group flex items-center gap-4 px-5 py-4 transition hover:bg-red-50/40 sm:px-6"
                  >
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        className="h-4 w-4"
                      >
                        <circle
                          cx="12"
                          cy="12"
                          r="8"
                          strokeWidth="1.8"
                        />

                        <path
                          d="M12 8v4m0 4h.01"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                        />
                      </svg>
                    </div>


                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-slate-800">
                        {taskTitle(
                          task,
                        )}
                      </div>

                      <div className="mt-1 text-xs text-red-500">
                        {uiText(isAr, 'text0026')}{' '}

                        {
                          task.deadlineDate
                        }
                      </div>
                    </div>


                    <StatusBadge
                      value={
                        task.status
                      }
                      listType="task_status"
                    />
                  </Link>
                ),
              )}


              {attentionProjects.length >
                0 && (
                <div className="bg-slate-50 px-5 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500 sm:px-6">
                  {uiText(isAr, 'text0405')}
                </div>
              )}


              {attentionProjects.map(
                (
                  project,
                ) => (
                  <Link
                    key={
                      project.id
                    }
                    href={`/projects/${project.id}`}
                    className="group flex items-center gap-4 px-5 py-4 transition hover:bg-red-50/40 sm:px-6"
                  >
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        className="h-4 w-4"
                      >
                        <path
                          d="M4 7h16v12H4zM8 7V5h8v2"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </div>


                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-slate-800">
                        {
                          project.name
                        }
                      </div>

                      <div className="mt-1 text-xs text-red-500">
                        {uiText(isAr, 'text0026')}{' '}
                        {
                          project.endDate
                        }
                      </div>
                    </div>


                    <StatusBadge
                      value={
                        project.status
                      }
                      listType="project_status"
                    />
                  </Link>
                ),
              )}
            </div>
          )}
        </div>


        {/*
         * UPCOMING
         */}

        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <div className="border-b border-slate-100 p-5 sm:p-6">
            <SectionHeader
              title={
                uiText(isAr, 'text0027')
              }
              description={
                uiText(isAr, 'text0292')
              }
            />
          </div>


          {upcoming.length ===
            0 &&
          upcomingProjects.length ===
            0 ? (
            <EmptyState
              title={
                uiText(isAr, 'text0028')
              }
              description={
                uiText(isAr, 'text0293')
              }
            />
          ) : (
            <div className="divide-y divide-slate-100">
              {upcoming.length >
                0 && (
                <div className="bg-slate-50 px-5 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500 sm:px-6">
                  {uiText(isAr, 'text1020')}
                </div>
              )}


              {upcoming
                .slice(
                  0,
                  5,
                )
                .map(
                  (
                    task,
                  ) => (
                    <Link
                      key={
                        task.id
                      }
                      href={`/tasks/${task.id}`}
                      className="group flex items-center gap-4 px-5 py-4 transition hover:bg-slate-50 sm:px-6"
                    >
                      <div className="flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-xl bg-slate-100">
                        <span className="text-[9px] font-semibold uppercase text-slate-400">
                          {task.deadlineDate
                            ? new Intl.DateTimeFormat(
                                locale,
                                {
                                  month:
                                    'short',
                                },
                              ).format(
                                new Date(
                                  task.deadlineDate,
                                ),
                              )
                            : ''}
                        </span>

                        <span className="text-sm font-semibold text-slate-700">
                          {task.deadlineDate
                            ? new Date(
                                task.deadlineDate,
                              ).getDate()
                            : ''}
                        </span>
                      </div>


                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium text-slate-800">
                          {taskTitle(
                            task,
                          )}
                        </div>

                        <div className="mt-1 text-xs text-slate-400">
                          {getLabel(
                            'task_priority',
                            task.priority,
                          )}
                        </div>
                      </div>


                      <StatusBadge
                        value={
                          task.status
                        }
                        listType="task_status"
                      />
                    </Link>
                  ),
                )}


              {upcomingProjects.length >
                0 && (
                <div className="bg-slate-50 px-5 py-2 text-xs font-semibold uppercase tracking-wider text-slate-500 sm:px-6">
                  {uiText(isAr, 'text0405')}
                </div>
              )}


              {upcomingProjects.map(
                (
                  project,
                ) => (
                  <Link
                    key={
                      project.id
                    }
                    href={`/projects/${project.id}`}
                    className="group flex items-center gap-4 px-5 py-4 transition hover:bg-slate-50 sm:px-6"
                  >
                    <div className="flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-xl bg-slate-100">
                      <span className="text-[9px] font-semibold uppercase text-slate-400">
                        {project.endDate
                          ? new Intl.DateTimeFormat(
                              locale,
                              {
                                month:
                                  'short',
                              },
                            ).format(
                              new Date(
                                `${project.endDate}T00:00:00`,
                              ),
                            )
                          : ''}
                      </span>

                      <span className="text-sm font-semibold text-slate-700">
                        {project.endDate
                          ? new Date(
                              `${project.endDate}T00:00:00`,
                            ).getDate()
                          : ''}
                      </span>
                    </div>


                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-slate-800">
                        {
                          project.name
                        }
                      </div>
                    </div>


                    <StatusBadge
                      value={
                        project.status
                      }
                      listType="project_status"
                    />
                  </Link>
                ),
              )}
            </div>
          )}
        </div>
      </section>


      {/*
       * ======================================================
       * RECENT TASKS
       * ======================================================
       */}

      <section className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <div className="border-b border-slate-100 p-5 sm:p-6">
          <SectionHeader
            title={
              uiText(isAr, 'text0029')
            }
            description={
              uiText(isAr, 'text0294')
            }
            action={
              <Link
                href={
                  taskListHref()
                }
                className="text-xs font-medium text-brand-600 hover:text-brand-800"
              >
                {uiText(isAr, 'text0030')}
              </Link>
            }
          />
        </div>


        {latestTasks.length ===
        0 ? (
          <EmptyState
            title={
              uiText(isAr, 'text0031')
            }
            description={
              uiText(isAr, 'text0295')
            }
          />
        ) : (
          <div className="divide-y divide-slate-100">
            {latestTasks.map(
              (
                task,
              ) => (
                <Link
                  key={
                    task.id
                  }
                  href={`/tasks/${task.id}`}
                  className="group grid gap-3 px-5 py-4 transition hover:bg-slate-50 sm:grid-cols-[minmax(0,1fr)_150px_150px] sm:items-center sm:px-6"
                >
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium text-slate-800 group-hover:text-brand-700">
                      {taskTitle(
                        task,
                      )}
                    </div>

                    <div className="mt-1 text-xs text-slate-400">
                      {uiText(isAr, 'text0032')}{' '}

                      {new Date(
                        task.createdAt,
                      ).toLocaleDateString(
                        locale,
                      )}
                    </div>
                  </div>


                  <div className="flex sm:justify-center">
                    <StatusBadge
                      value={
                        task.priority
                      }
                      listType="task_priority"
                    />
                  </div>


                  <div className="flex sm:justify-end">
                    <StatusBadge
                      value={
                        task.status
                      }
                      listType="task_status"
                    />
                  </div>
                </Link>
              ),
            )}
          </div>
        )}
      </section>


      {/*
       * ======================================================
       * RECENT PROJECTS
       * ======================================================
       */}

      <section className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <div className="border-b border-slate-100 p-5 sm:p-6">
          <SectionHeader
            title={
              uiText(isAr, 'text1044')
            }
            description={
              uiText(isAr, 'text1045')
            }
            action={
              <Link
                href="/projects"
                className="text-xs font-medium text-brand-600 hover:text-brand-800"
              >
                {uiText(isAr, 'text1046')}
              </Link>
            }
          />
        </div>


        {latestProjects.length ===
        0 ? (
          <EmptyState
            title={
              uiText(isAr, 'text1047')
            }
            description={
              uiText(isAr, 'text1048')
            }
          />
        ) : (
          <div className="divide-y divide-slate-100">
            {latestProjects.map(
              (
                project,
              ) => {
                const overdue =
                  dashboardProjectIsOverdue(
                    project,
                  );


                return (
                  <Link
                    key={
                      project.id
                    }
                    href={`/projects/${project.id}`}
                    className="group grid gap-3 px-5 py-4 transition hover:bg-slate-50 sm:grid-cols-[minmax(0,1fr)_150px_150px] sm:items-center sm:px-6"
                  >
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium text-slate-800 group-hover:text-brand-700">
                        {
                          project.name
                        }
                      </div>

                      <div className="mt-1 text-xs text-slate-400">
                        {uiText(isAr, 'text0032')}{' '}

                        {new Date(
                          project.createdAt,
                        ).toLocaleDateString(
                          locale,
                        )}
                      </div>
                    </div>


                    <div className="flex sm:justify-center">
                      {overdue ? (
                        <span className="rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700">
                          {uiText(isAr, 'text0075')}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-500">
                          {formatProjectDate(
                            project.endDate,
                            locale,
                          )}
                        </span>
                      )}
                    </div>


                    <div className="flex sm:justify-end">
                      <StatusBadge
                        value={
                          project.status
                        }
                        listType="project_status"
                      />
                    </div>
                  </Link>
                );
              },
            )}
          </div>
        )}
      </section>


      {/*
       * ======================================================
       * FILTER SHORTCUTS
       * ======================================================
       */}

      <section className="mt-6 grid gap-6 xl:grid-cols-3">
        {/*
         * TYPES
         */}

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <SectionHeader
            title={
              uiText(isAr, 'text0033')
            }
            description={
              uiText(isAr, 'text0296')
            }
          />


          <div className="mt-5 space-y-2">
            {typeCounts.length >
            0 ? (
              typeCounts.map(
                (
                  item,
                ) => (
                  <Link
                    key={
                      item.taskType
                    }
                    href={
                      taskListHref(
                        `taskType=${encodeURIComponent(
                          item.taskType,
                        )}`,
                      )
                    }
                    className="flex items-center justify-between rounded-xl px-3 py-2.5 transition hover:bg-slate-50"
                  >
                    <span className="truncate text-sm text-slate-600">
                      {
                        item.label
                      }
                    </span>

                    <span className="flex h-7 min-w-7 items-center justify-center rounded-lg bg-slate-100 px-2 text-xs font-semibold text-slate-700">
                      {
                        item.count
                      }
                    </span>
                  </Link>
                ),
              )
            ) : (
              <p className="text-sm text-slate-400">
                —
              </p>
            )}
          </div>
        </div>


        {/*
         * PRIORITY
         */}

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <SectionHeader
            title={
              uiText(isAr, 'text0297')
            }
            description={
              uiText(isAr, 'text0298')
            }
          />


          <div className="mt-5 space-y-2">
            {priorityCounts.length >
            0 ? (
              priorityCounts.map(
                (
                  item,
                ) => (
                  <Link
                    key={
                      item.priority
                    }
                    href={
                      taskListHref(
                        `priority=${encodeURIComponent(
                          item.priority,
                        )}`,
                      )
                    }
                    className="flex items-center justify-between rounded-xl px-3 py-2.5 transition hover:bg-slate-50"
                  >
                    <StatusBadge
                      value={
                        item.priority
                      }
                      listType="task_priority"
                    />

                    <span className="flex h-7 min-w-7 items-center justify-center rounded-lg bg-slate-100 px-2 text-xs font-semibold text-slate-700">
                      {
                        item.count
                      }
                    </span>
                  </Link>
                ),
              )
            ) : (
              <p className="text-sm text-slate-400">
                —
              </p>
            )}
          </div>
        </div>


        {/*
         * PROJECT STATUS
         */}

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <SectionHeader
            title={
              uiText(isAr, 'text0299')
            }
            description={
              uiText(isAr, 'text0300')
            }
          />


          <div className="mt-5 space-y-2">
            {projectStatusCounts.length >
            0 ? (
              projectStatusCounts.map(
                (
                  item,
                ) => (
                  <Link
                    key={
                      item.status
                    }
                    href={`/projects?status=${encodeURIComponent(
                      item.status,
                    )}`}
                    className="flex items-center justify-between rounded-xl px-3 py-2.5 transition hover:bg-slate-50"
                  >
                    <StatusBadge
                      value={
                        item.status
                      }
                      listType="project_status"
                    />

                    <span className="flex h-7 min-w-7 items-center justify-center rounded-lg bg-slate-100 px-2 text-xs font-semibold text-slate-700">
                      {
                        item.count
                      }
                    </span>
                  </Link>
                ),
              )
            ) : (
              <p className="text-sm text-slate-400">
                —
              </p>
            )}
          </div>
        </div>
      </section>


      {/*
       * ======================================================
       * ANALYTICS
       * ======================================================
       */}

      <section className="mt-10">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[.14em] text-brand-600">
            {uiText(isAr, 'text0034')}
          </div>

          <h2 className="mt-2 text-xl font-semibold tracking-tight text-slate-900">
            {isAdmin
              ? uiText(isAr, 'text0301')
              : uiText(isAr, 'text0302')}
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            {isAdmin
              ? uiText(isAr, 'text0303')
              : uiText(isAr, 'text0304')}
          </p>
        </div>


        {statsError && (
          <div className="mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {
              statsError
            }
          </div>
        )}


        {statsLoading ? (
          <InlineLoader className="mt-6 min-h-64" />
        ) : (
          <>
            {/*
             * =================================================
             * MONTHLY CHART
             * =================================================
             */}

            <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white">
              <div className="border-b border-slate-100 p-5 sm:p-6">
                <SectionHeader
                  title={
                    uiText(isAr, 'text0305')
                  }
                  description={
                    uiText(isAr, 'text0306')
                  }
                  action={
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="h-2 w-2 rounded-full bg-brand-500" />

                      {uiText(isAr, 'text0307')}
                    </div>
                  }
                />
              </div>


              {monthlyChartData.length ===
              0 ? (
                <ChartEmptyState
                  message={
                    uiText(isAr, 'text0035')
                  }
                />
              ) : (
                <div className="h-[370px] p-4 sm:p-6" dir="ltr">
                  <ResponsiveContainer
                    width="100%"
                    height="100%"
                  >
                    <LineChart
                      data={
                        monthlyChartData
                      }
                      margin={{
                        top: 10,
                        right: 18,
                        bottom: 4,
                        left: -18,
                      }}
                    >
                      <CartesianGrid
                        vertical={
                          false
                        }
                        stroke="#e2e8f0"
                        strokeDasharray="3 6"
                      />


                      <XAxis
                        dataKey="month"
                        axisLine={
                          false
                        }
                        tickLine={
                          false
                        }
                        dy={
                          10
                        }
                        tick={{
                          fontSize: 11,
                          fill: '#64748b',
                        }}
                      />


                      <YAxis
                        allowDecimals={
                          false
                        }
                        axisLine={
                          false
                        }
                        tickLine={
                          false
                        }
                        tick={{
                          fontSize: 11,
                          fill: '#94a3b8',
                        }}
                      />


                      <Tooltip
                        cursor={{
                          stroke:
                            '#cbd5e1',

                          strokeDasharray:
                            '4 4',
                        }}
                        contentStyle={{
                          borderRadius:
                            '12px',

                          border:
                            '1px solid #e2e8f0',

                          boxShadow:
                            '0 14px 35px rgba(15,23,42,.1)',

                          fontSize:
                            '12px',

                          direction:
                            isAr ? 'rtl' : 'ltr',

                          textAlign:
                            isAr ? 'right' : 'left',
                        }}
                      />


                      <Legend
                        iconType="circle"
                        wrapperStyle={{
                          paddingTop:
                            '18px',

                          fontSize:
                            '12px',
                        }}
                      />


                      <Line
                        type="monotone"
                        dataKey="Completed"
                        name={uiText(isAr, 'text0018')}
                        stroke="#16a34a"
                        strokeWidth={
                          2.5
                        }
                        dot={{
                          r: 2.5,
                        }}
                        activeDot={{
                          r: 5,
                        }}
                      />


                      <Line
                        type="monotone"
                        dataKey="Not completed"
                        name={uiText(isAr, 'text0773')}
                        stroke="var(--theme-primary)"
                        strokeWidth={
                          2.5
                        }
                        dot={{
                          r: 2.5,
                        }}
                        activeDot={{
                          r: 5,
                        }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>


            {/*
             * =================================================
             * BRANCH / DEPARTMENT
             * =================================================
             */}

            <div className="mt-6 grid gap-6 xl:grid-cols-2">
                {/*
                 * BRANCH
                 */}

                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
                  <div className="border-b border-slate-100 p-5 sm:p-6">
                    <SectionHeader
                      title={
                        uiText(isAr, 'text0308')
                      }
                      description={
                        uiText(isAr, 'text0309')
                      }
                    />
                  </div>


                  {branchChartData.length ===
                  0 ? (
                    <ChartEmptyState
                      message={
                        uiText(isAr, 'text0310')
                      }
                    />
                  ) : (
                    <div
                      className="overflow-y-auto px-2 py-5 sm:px-4"
                      style={{
                        maxHeight:
                          '520px',
                      }}
                    >
                      <div
                        dir="ltr"
                        style={{
                          height:
                            branchChartHeight,
                        }}
                      >
                        <ResponsiveContainer
                          width="100%"
                          height="100%"
                        >
                          <BarChart
                            data={
                              branchChartData
                            }
                            layout="vertical"
                            barCategoryGap="30%"
                            margin={{
                              top: 4,
                              right: 28,
                              bottom: 4,
                              left: 8,
                            }}
                          >
                            <CartesianGrid
                              horizontal={
                                false
                              }
                              stroke="#e2e8f0"
                              strokeDasharray="3 6"
                            />


                            <XAxis
                              type="number"
                              allowDecimals={
                                false
                              }
                              axisLine={
                                false
                              }
                              tickLine={
                                false
                              }
                              tick={{
                                fontSize:
                                  10,

                                fill:
                                  '#94a3b8',
                              }}
                            />


                            <YAxis
                              dataKey="name"
                              type="category"
                              width={
                                110
                              }
                              axisLine={
                                false
                              }
                              tickLine={
                                false
                              }
                              tick={{
                                fontSize:
                                  11,

                                fill:
                                  '#475569',
                              }}
                            />


                            <Tooltip
                              wrapperStyle={{
                                direction:
                                  isAr ? 'rtl' : 'ltr',

                                textAlign:
                                  isAr ? 'right' : 'left',
                              }}
                              contentStyle={{
                                borderRadius:
                                  '12px',

                                border:
                                  '1px solid #e2e8f0',

                                boxShadow:
                                  '0 14px 35px rgba(15,23,42,.1)',

                                fontSize:
                                  '12px',
                              }}
                            />


                            <Legend
                              iconType="circle"
                              wrapperStyle={{
                                fontSize:
                                  '11px',
                              }}
                            />


                            <Bar
                              dataKey="Completed"
                              name={uiText(isAr, 'text0018')}
                              fill="#16a34a"
                              radius={[
                                0,
                                6,
                                6,
                                0,
                              ]}
                              maxBarSize={
                                16
                              }
                            />


                            <Bar
                              dataKey="Overdue"
                              name={uiText(isAr, 'text0285')}
                              fill="#dc2626"
                              radius={[
                                0,
                                6,
                                6,
                                0,
                              ]}
                              maxBarSize={
                                16
                              }
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}
                </div>


                {/*
                 * DEPARTMENT
                 */}

                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
                  <div className="border-b border-slate-100 p-5 sm:p-6">
                    <SectionHeader
                      title={
                        uiText(isAr, 'text0311')
                      }
                      description={
                        uiText(isAr, 'text0312')
                      }
                    />
                  </div>


                  {departmentChartData.length ===
                  0 ? (
                    <ChartEmptyState
                      message={
                        uiText(isAr, 'text0313')
                      }
                    />
                  ) : (
                    <div
                      className="overflow-y-auto px-2 py-5 sm:px-4"
                      style={{
                        maxHeight:
                          '520px',
                      }}
                    >
                      <div
                        dir="ltr"
                        style={{
                          height:
                            departmentChartHeight,
                        }}
                      >
                        <ResponsiveContainer
                          width="100%"
                          height="100%"
                        >
                          <BarChart
                            data={
                              departmentChartData
                            }
                            layout="vertical"
                            barCategoryGap="30%"
                            margin={{
                              top: 4,
                              right: 28,
                              bottom: 4,
                              left: 8,
                            }}
                          >
                            <CartesianGrid
                              horizontal={
                                false
                              }
                              stroke="#e2e8f0"
                              strokeDasharray="3 6"
                            />


                            <XAxis
                              type="number"
                              allowDecimals={
                                false
                              }
                              axisLine={
                                false
                              }
                              tickLine={
                                false
                              }
                              tick={{
                                fontSize:
                                  10,

                                fill:
                                  '#94a3b8',
                              }}
                            />


                            <YAxis
                              dataKey="name"
                              type="category"
                              width={
                                110
                              }
                              axisLine={
                                false
                              }
                              tickLine={
                                false
                              }
                              tick={{
                                fontSize:
                                  11,

                                fill:
                                  '#475569',
                              }}
                            />


                            <Tooltip
                              wrapperStyle={{
                                direction:
                                  isAr ? 'rtl' : 'ltr',

                                textAlign:
                                  isAr ? 'right' : 'left',
                              }}
                              contentStyle={{
                                borderRadius:
                                  '12px',

                                border:
                                  '1px solid #e2e8f0',

                                boxShadow:
                                  '0 14px 35px rgba(15,23,42,.1)',

                                fontSize:
                                  '12px',
                              }}
                            />


                            <Legend
                              iconType="circle"
                              wrapperStyle={{
                                fontSize:
                                  '11px',
                              }}
                            />


                            <Bar
                              dataKey="Completed"
                              name={uiText(isAr, 'text0018')}
                              fill="#16a34a"
                              radius={[
                                0,
                                6,
                                6,
                                0,
                              ]}
                              maxBarSize={
                                16
                              }
                            />


                            <Bar
                              dataKey="Overdue"
                              name={uiText(isAr, 'text0285')}
                              fill="#dc2626"
                              radius={[
                                0,
                                6,
                                6,
                                0,
                              ]}
                              maxBarSize={
                                16
                              }
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}
                </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}


/*
 * ============================================================
 * PAGE
 * ============================================================
 */

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  );
}
